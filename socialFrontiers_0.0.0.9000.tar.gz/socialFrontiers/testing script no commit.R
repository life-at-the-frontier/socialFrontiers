library(checkpoint)
checkpoint('2020-01-01')

## older inla

# install.packages("INLA",repos=c(getOption("repos"),INLA="https://inla.r-inla-download.org/R/testing"), dep=TRUE)
#
# library(remotes)
# remotes::install_version("INLA",
#                          version="18.07.12",
#                          repos=c(getOption("repos"),INLA="https://inla.r-inla-download.org/R/stable"), dep=TRUE)


require(devtools)
install_github(
  "menglezhang/socialfrontiers@v0.2",
#  ref = 'dev',
  build_opts = c("--no-resave-data", "--no-manual"),
  build_vignettes = F
)

?socialFrontiers
socialFrontiers:::binomial_localisedINLA

packageDescription('socialFrontiers')


borders_sf %>%  sf::as_spatial()
class(borders_sf)[1] <- NULL
class(borders_sf)[1] <- 'Spatial'

library(sf)
tm_shape(barnet) +
  tm_fill(col= 'propNonUK') #+
  qtm(borders_sf %>% st_geometry()) # works

barnet %>% class
borders_sf %>% class

tm_shape(borders_sf) # works

borders_sf %>% sf::st_sfc() %>% plot
?tmap
?sf
tm_sh
