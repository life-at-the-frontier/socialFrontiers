## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(socialFrontiers)
library(dplyr)

## ----load data----------------------------------------------------------------
data(london)

##  Filter to the borough of Barnet
barnet <-
  london %>%
  filter(substr(LSOAname, 1, 6) %in% 'Barnet')


## ----set parameters-----------------------------------------------------------
y <- 'nonUK' # 'nonUK' # Number of foreign
n.trials <- 'totalPop' #total population (per zone?)

## ----run frontier_detect()----------------------------------------------------
frontier_model <-
  frontier_detect(
    data = barnet,
    y = y, n.trials = n.trials)

class(frontier_model) # Outputs a frontier_model object

## ----summary method-----------------------------------------------------------
summary(frontier_model) ## This calls up summary.frontier_model

## ----sf methods, message=FALSE------------------------------------------------
suppressWarnings(borders_sf <-
                   frontier_as_sf(frontier_model, silent = T))

class(borders_sf) 

## ----sf graphing--------------------------------------------------------------
library(tmap)

##  Create a variable for prop-non-UK
barnet <-
  barnet %>%
  mutate(propNonUK = nonUK/totalPop)

tm_shape(barnet) +
  tm_fill(col= 'propNonUK') +
  qtm(borders_sf) # works

